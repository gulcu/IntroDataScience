# most_common_words.py
import sys
from collections import Counter

if __name__ == "__main__":

    # pass in number of words as first argument
    try:
        num_words = int(sys.argv[1])
        filename = sys.argv[2]
        file = open(filename, 'r')   #  file to open is specified at the command prompt as the 2nd argument
    except:
        print("usage: most_common_words.py num_words filename")
        sys.exit(1)   # non-zero exit code indicates error

    counter = Counter(word.lower()
                      for line in file   #
                      for word in line.strip().split()
                      if word)

    file.close()

    for word, count in counter.most_common(num_words):
        sys.stdout.write(str(count))
        sys.stdout.write("\t")
        sys.stdout.write(word)
        sys.stdout.write("\n")



# python 5most_common_words_FileRead.py 10 hamlet.txt

# Download hamlet.txt from:
# http://courses.cs.washington.edu/courses/cse341/07wi/handouts/hamlet.txt