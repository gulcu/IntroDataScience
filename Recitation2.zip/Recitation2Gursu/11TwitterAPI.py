import requests, json
endpoint = "https://api.github.com/users/joelgrus/repos"
repos = json.loads(requests.get(endpoint).text)

from dateutil.parser import parse
dates = [parse(repo["created_at"]) for repo in repos]
month_counts = Counter(date.month for date in dates)
weekday_counts = Counter(date.weekday() for date in dates)

last_5_repositories = sorted(repos,key=lambda r: r["created_at"],reverse=True)[:5]
last_5_languages = [repo["language"] for repo in last_5_repositories]

from twython import Twython

twitter = Twython(CONSUMER KEY,CONSUMER SECRET)

# search for tweets containing the phrase "data science"
for status in twitter.search(q='"data science"')["statuses"]:
    user = status["user"]["screen_name"].encode('utf-8')
    text = status["text"].encode('utf-8')
    print(user, ":", text)
    print
    
from twython import TwythonStreamer

# appending data to a global variable is pretty poor form but it makes the example much simpler
tweets = []

class MyStreamer(TwythonStreamer):
    #specifies how to interact with the stream"""
    
    def on_success(self, data):
        # data will be a Python dict representing a tweet
        # only want to collect English-language tweets
        if data['lang'] == 'en':
            tweets.append(data)
            print("received tweet #", len(tweets))
        # stop when we've collected enough
        if len(tweets) >= 100:
            self.disconnect()
    def on_error(self, status_code, data):
        print(status_code, data)
        self.disconnect()
        
stream = MyStreamer(CONSUMER KEY, CONSUMER SECRET, ACCESS TOKEN, ACCESS SECRET)

# starts consuming public statuses that contain the keyword 'data'

stream.statuses.filter(track='data')
# if instead we wanted to start consuming a sample of *all* public statuses
# stream.statuses.sample()
# This will run until it collects 1,000 tweets (or until it encounters an error) and stop, at

top_hashtags = Counter(hashtag['text'].lower()
    for tweet in tweets
    for hashtag in tweet["entities"]["hashtags"])
print(top_hashtags.most_common(5))
