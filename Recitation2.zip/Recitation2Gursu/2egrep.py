# egrep.py
# sys provides access to some variables used or maintained by the interpreter 
# 	and to functions that interact strongly with the interpreter
import sys, re

# this code only executes when run as a program, and not when imported as a module
if __name__ == "__main__":

    # sys.argv is the list of command-line arguments
    # sys.argv[0] is the name of the program itself
    # sys.argv[1] will be the regex specfied at the command line
    regex = sys.argv[1]

    # for every line passed into the script
    for line in sys.stdin:
        # if it matches the regex, write it to stdout
        if re.search(regex, line):
            sys.stdout.write(line)

# On Linux, Mac:	
# cat comma_delimited_stock_prices.txt | python 2egrep.py "[0-9]" | python 3line_count.py
# On Windows:
# type comma_delimited_stock_prices.txt | python 2egrep.py "[0-9]" | python 3line_count.py