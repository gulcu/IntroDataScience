from urllib.request import urlopen

url = "http://courses.cs.washington.edu/courses/cse341/07wi/handouts/hamlet.txt"
response = urlopen(url)

lines = response.readlines()

f = open('hamletWEB.txt', 'w+')

for line in lines:
    f.write(line.decode('utf-8'))

f.close()