import csv

dates = []
stockPrices = {}

def process(date, symbol, closing_price):
    print(date, symbol, closing_price)
    if not symbol in stockPrices: stockPrices[symbol]={}
    stockPrices[symbol][date] = closing_price


with open('tab_delimited_stock_prices.txt', 'r') as f:
    reader = csv.reader(f, delimiter='\t')
    rows = []
    
    #next(reader)   # to skip the first line, if there were headers for example
    for row in reader:
        rows.append(row)
        date = row[0]
        symbol = row[1]
        closing_price = float(row[2])
        process(date, symbol, closing_price)
print(stockPrices)
print("\n")

stockPrices = {}

with open('colon_delimited_stock_prices.txt', 'r') as f:
    reader = csv.DictReader(f, delimiter=':')
    for row in reader:
        date = row["date"]
        symbol = row["symbol"]
        closing_price = float(row["closing_price"])
        process(date, symbol, closing_price)
print(stockPrices)
print("\n")


today_prices = { 'AAPL' : 10.91, 'MSFT' : 10.68, 'FB' : 10.5 }
with open('comma_delimited_stock_prices.txt','a+') as f:   # 'a+' for appending to file
    writer = csv.writer(f, delimiter=',')
    for stock, price in today_prices.items():
        writer.writerow([stock, price])