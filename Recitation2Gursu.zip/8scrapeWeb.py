# conda install lxml

from bs4 import BeautifulSoup
import requests
html = requests.get("http://haacked.com/").text
soup = BeautifulSoup(html, 'lxml')

first_paragraph = soup.find('p')  # or just soup.p
print(first_paragraph)
# You can get the text contents of a Tag using its text property:
first_paragraph_text = soup.p.text
print(first_paragraph_text)

first_paragraph_words = soup.p.text.split()
print(first_paragraph_words)

spans_inside_divs = [span for div in soup('div') for span in div('span')]
# for each <div> on the page, find each <span> inside it
